import pylint.lint
pylint_opts = ['ex1.py', 'ex2.py', 'ex3.py', 'ex4.py', 'ex5.py', 'ex6.py']
pylint.lint.Run(pylint_opts)
